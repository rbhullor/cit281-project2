/*
CIT 281 Project 2
Name: Reiya Bhullor
*/

//Returns a single, random, lowercase letter from the alphabet
function getRandomLetter() {
    const alphabet = 'abcdefghijklmnopqrstuvwxyz';
    const randomIndex = Math.floor(Math.random() * alphabet.length);
    return alphabet.charAt(randomIndex);
  }
  
  console.log(getRandomLetter());
  
//returns the random length string with 10 being the minimum length and 20 being the max
    function getRandomInteger(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
      }
  
  function getRandomString(minLength, maxLength) {
    const length = getRandomInteger(minLength, maxLength);
    let str = '';
    for (let i = 0; i < length; i++){
      str += getRandomLetter();
    }
    return str;
  }
  
  console.log(getRandomString(10, 20));

//returns a string in ascending order (i.e., xpacd would return acdpx)
const sortedString = getRandomString(10, 20).split('').sort().join('');
console.log(sortedString); 

//working on Once staged, the file will be moved into a new section called Staged Changes, indicating the file is ready to commit. Select the staged file, then select the Commit icon (the check mark icon) to commit the staged file. Use the documentation message, "Filed added" and press the Enter key to complete the commit process. See the images below.